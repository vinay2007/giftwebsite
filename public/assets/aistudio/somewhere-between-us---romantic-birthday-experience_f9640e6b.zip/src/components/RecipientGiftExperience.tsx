import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Edit3, ArrowLeft } from 'lucide-react';
import { GiftData } from '../config/giftConfig';
import { CosmicBackground } from './CosmicBackground';
import { ChapterNavigation } from './ChapterNavigation';
import { Chapter01Opening } from './Chapter01Opening';
import { Chapter02Memories } from './Chapter02Memories';
import { Chapter03Letter } from './Chapter03Letter';
import { Chapter04Reveal } from './Chapter04Reveal';
import { Chapter05Envelope } from './Chapter05Envelope';

interface RecipientGiftExperienceProps {
  gift: GiftData;
  onBackToEditor?: () => void;
  isPreviewMode?: boolean;
}

export const RecipientGiftExperience: React.FC<RecipientGiftExperienceProps> = ({
  gift,
  onBackToEditor,
  isPreviewMode = false,
}) => {
  const [activeChapterIndex, setActiveChapterIndex] = useState(0);
  const [isOpeningEntered, setIsOpeningEntered] = useState(false);

  // Active theme font class
  const fontClass =
    gift.theme?.fontPairing === 'playfair'
      ? 'font-["Playfair_Display",serif]'
      : gift.theme?.fontPairing === 'editorial'
      ? 'font-["Fraunces",serif]'
      : 'font-["Cormorant_Garamond",serif]';

  // Palette background and accent
  const paletteBg =
    gift.theme?.palette === 'indigo'
      ? 'bg-[#060813]'
      : gift.theme?.palette === 'rosewood'
      ? 'bg-[#0f080b]'
      : gift.theme?.palette === 'starlight'
      ? 'bg-[#040405]'
      : 'bg-[#070709]';

  // Ensure all 5 chapters are always available, upgrading older 4-chapter drafts seamlessly
  const resolvedChapters = React.useMemo(() => {
    const list = [...(gift.chapters || [])];
    const ch4 = list.find((c) => c.number === '04' || c.id === 'reveal');
    if (ch4 && ch4.title === 'One last thing') {
      ch4.title = 'Voices & Melodies';
      ch4.subtitle = 'A song and voice recorded for you';
    }
    if (!list.some((c) => c.id === 'envelope' || c.number === '05')) {
      list.push({
        id: 'envelope',
        number: '05',
        title: 'The sealed letter',
        subtitle: "There's one last thing for you",
        enabled: true,
      });
    }
    return list;
  }, [gift.chapters]);

  const handleNext = useCallback(() => {
    setActiveChapterIndex((prev) => Math.min(prev + 1, resolvedChapters.length - 1));
  }, [resolvedChapters.length]);

  const handlePrev = useCallback(() => {
    setActiveChapterIndex((prev) => Math.max(prev - 1, 0));
  }, []);

  const handleEnterFromOpening = () => {
    setIsOpeningEntered(true);
    setActiveChapterIndex(1); // smoothly transition to Chapter 02 (Memories)
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (['INPUT', 'TEXTAREA'].includes(target.tagName)) return;

      if (e.key === 'ArrowRight' && isOpeningEntered) {
        handleNext();
      } else if (e.key === 'ArrowLeft' && isOpeningEntered) {
        handlePrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpeningEntered, handleNext, handlePrev]);

  return (
    <div className={`relative min-h-screen w-full ${paletteBg} text-zinc-100 font-sans selection:bg-amber-300/20 selection:text-white overflow-hidden`}>
      {/* Dynamic Cosmic Background */}
      <CosmicBackground
        activeChapterIndex={activeChapterIndex}
        enableParallax={gift.settings.enableParallax}
        palette={gift.theme?.palette}
        animationIntensity={gift.theme?.animationIntensity}
      />

      {/* Discreet floating "Return to Editor" button when in preview mode */}
      {isPreviewMode && onBackToEditor && (
        <div className="fixed top-5 left-5 z-50">
          <button
            onClick={onBackToEditor}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-950/80 hover:bg-zinc-900 border border-zinc-700/80 hover:border-amber-200/50 text-zinc-300 hover:text-white text-xs backdrop-blur-md shadow-lg transition-all"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span className="font-sans text-[11px]">Back to Editor</span>
          </button>
        </div>
      )}

      {/* Top Bar Contract (Visible once entered) */}
      {isOpeningEntered && (
        <header className="fixed top-0 inset-x-0 z-40 flex items-center justify-between gap-8 px-6 md:px-12 py-5 border-b border-zinc-800/40 bg-zinc-950/30 backdrop-blur-md">
          {/* Zone 1: Single text wordmark */}
          <button
            onClick={() => setActiveChapterIndex(0)}
            className={`text-base sm:text-lg italic text-zinc-200 hover:text-amber-200 transition-colors whitespace-nowrap shrink-0 text-left focus-visible:outline-none ${fontClass}`}
          >
            {gift.siteTitle || gift.title}
          </button>

          {/* Zone 2: Clean single-line text links */}
          <nav className="hidden md:flex items-center gap-6 text-xs uppercase tracking-widest text-zinc-400">
            {resolvedChapters.map((chap, idx) => (
              <button
                key={chap.id}
                onClick={() => setActiveChapterIndex(idx)}
                className={`whitespace-nowrap shrink-0 transition-colors pb-1 border-b ${
                  activeChapterIndex === idx
                    ? 'border-amber-200/90 text-zinc-100 font-medium'
                    : 'border-transparent hover:text-zinc-200'
                }`}
              >
                {chap.number}. {chap.title}
              </button>
            ))}
          </nav>

          {/* Zone 3: Quiet recipient indicator */}
          <div className="flex items-center gap-3 shrink-0">
            <span className={`text-xs italic text-zinc-400 ${fontClass}`}>
              For {gift.recipientNickname || 'you'}
            </span>
          </div>
        </header>
      )}

      {/* Main Chapter Content Viewport */}
      <main className="relative z-10 w-full min-h-screen flex items-center justify-center">
        <AnimatePresence mode="wait">
          {activeChapterIndex === 0 && (
            <motion.div
              key="chapter-01"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="w-full"
            >
              <Chapter01Opening
                config={gift}
                onEnter={handleEnterFromOpening}
              />
            </motion.div>
          )}

          {activeChapterIndex === 1 && (
            <motion.div
              key="chapter-02"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="w-full"
            >
              <Chapter02Memories
                photos={gift.photos}
                recipientNickname={gift.recipientNickname}
              />
            </motion.div>
          )}

          {activeChapterIndex === 2 && (
            <motion.div
              key="chapter-03"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="w-full"
            >
              <Chapter03Letter config={gift} />
            </motion.div>
          )}

          {activeChapterIndex === 3 && (
            <motion.div
              key="chapter-04"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="w-full"
            >
              <Chapter04Reveal
                config={gift}
                onGoToNextChapter={() => setActiveChapterIndex(4)}
              />
            </motion.div>
          )}

          {activeChapterIndex === 4 && (
            <motion.div
              key="chapter-05"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="w-full"
            >
              <Chapter05Envelope config={gift} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Chapter Navigation Controls */}
      <ChapterNavigation
        chapters={resolvedChapters}
        activeChapterIndex={activeChapterIndex}
        onSelectChapter={(idx) => {
          setIsOpeningEntered(true);
          setActiveChapterIndex(idx);
        }}
        onNext={handleNext}
        onPrev={handlePrev}
        isOpeningEntered={isOpeningEntered}
      />
    </div>
  );
};
